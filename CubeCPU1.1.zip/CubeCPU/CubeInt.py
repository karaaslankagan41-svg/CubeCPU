import argparse, time, os, sys
from multiprocessing import Process, Queue, cpu_count, set_start_method
import pygame, psutil

def rotl(x, r):
    return ((x << r) & 0xFFFFFFFFFFFFFFFF) | (x >> (64 - r))

def worker(idx, duration, q):
    try:
        psutil.Process(os.getpid()).cpu_affinity([idx])
    except Exception:
        pass
    end = time.time() + duration
    total = 0
    last_sent = time.time()
    ops_since_last = 0
    x = 0xABCDEF1234567890 ^ idx
    y = 0x123456789ABCDEF0 ^ (idx * 13)
    while time.time() < end:
        for _ in range(300000):
            x = (x * 6364136223846793005 + 1) & 0xFFFFFFFFFFFFFFFF
            x ^= rotl(x, (x & 63))
            y = (y ^ rotl(x, 13)) * 0x9E3779B97F4A7C15 & 0xFFFFFFFFFFFFFFFF
            x ^= y ^ (x >> 17)
            total += 1
            ops_since_last += 1
        now = time.time()
        if now - last_sent >= 1.0:
            try:
                q.put(("update", idx, ops_since_last, total))
            except:
                pass
            ops_since_last = 0
            last_sent = now
    try:
        q.put(("done", idx, ops_since_last, total))
    except:
        pass

def monitor(workers, duration, q):
    pygame.init()
    W, H = 800, 550
    screen = pygame.display.set_mode((W, H))
    pygame.display.set_caption("CubeInt Benchmark Monitor")
    font = pygame.font.SysFont("consolas", 18)
    big = pygame.font.SysFont("consolas", 22, bold=True)
    clock = pygame.time.Clock()
    start = time.time()
    data = {i: {"sec": 0, "total": 0, "done": False} for i in range(workers)}
    running = True
    while running:
        now = time.time()
        remaining = max(0.0, start + duration - now)
        while True:
            try:
                msg = q.get_nowait()
            except:
                break
            if msg[0] in ("update", "done"):
                _, idx, sec, total = msg
                data[idx]["sec"] = int(sec)
                data[idx]["total"] = int(total)
                if msg[0] == "done":
                    data[idx]["done"] = True
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
        cpu = psutil.cpu_percent(percpu=True)
        ram = psutil.virtual_memory()
        screen.fill((15, 12, 12))
        screen.blit(big.render("Integer Stress Monitor", True, (255, 200, 0)), (20, 10))
        screen.blit(font.render(f"Time Left: {remaining:5.1f}s", True, (230, 230, 230)), (20, 45))
        total_ops = sum(v["total"] for v in data.values())
        avg_ops = sum(v["sec"] for v in data.values()) / max(1, len(data))
        screen.blit(font.render(f"Total Ops: {total_ops}", True, (200, 255, 200)), (250, 45))
        screen.blit(font.render(f"Avg Ops/s per core: {avg_ops:.0f}", True, (200, 255, 200)), (520, 45))
        screen.blit(font.render(f"RAM: {ram.percent:.1f}% ({ram.used//(1024**2)} MB)", True, (255, 230, 130)), (20, 70))
        y = 110
        for i in range(workers):
            sec = data[i]["sec"]
            tot = data[i]["total"]
            done = data[i]["done"]
            cusage = cpu[i] if i < len(cpu) else 0
            status = "done" if done else "running"
            txt = f"Core {i:02d} | CPU% {cusage:5.1f} | ops/s {sec:7d} | total {tot:10d} | {status}"
            col = (255, 200, 100) if not done else (130, 130, 130)
            screen.blit(font.render(txt, True, col), (20, y))
            y += 26
        pygame.display.flip()
        clock.tick(8)
        if remaining <= 0 or all(v["done"] for v in data.values()):
            running = False
    pygame.quit()
    return sum(v["total"] for v in data.values())

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--core", choices=["single", "multi"], required=True)
    parser.add_argument("--duration", type=int, required=True)
    a = parser.parse_args()
    try:
        set_start_method("spawn")
    except:
        pass
    cores = 1 if a.core == "single" else cpu_count()
    q = Queue()
    procs = [Process(target=worker, args=(i, a.duration, q)) for i in range(cores)]
    for p in procs:
        p.start()
    total = monitor(cores, a.duration, q)
    for p in procs:
        try:
            p.join(timeout=0.5)
            if p.is_alive():
                p.terminate()
        except:
            pass
    print(f"Integer Stress Complete | Cores: {cores} | Duration: {a.duration}s | TotalOps: {total}")
