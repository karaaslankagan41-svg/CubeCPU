import time, sys

def int_test(duration=60):
    start = time.time()
    c = 1
    while time.time() - start < duration:
        c = (c * 13) ^ (c >> 7)
        c &= 0xFFFFFFFF
    print(f"Int test complete ({duration}s) result={c}")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--core", default="single")
    parser.add_argument("--duration", type=int, default=60)
    args = parser.parse_args()
    int_test(args.duration)
