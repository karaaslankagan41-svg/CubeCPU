import os
import sys
import ctypes
import subprocess
import pygame
import json

# ==== Admin kontrol ====
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if not is_admin():
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
    sys.exit()

# ==== Ayar dosyası ====
SETTINGS_FILE = "cube_settings.json"
default_settings = {
    "render": {
        "duration": 60,
        "profiles": {
            "extreme": {"lat": 100, "lon": 50},
            "balanced": {"lat": 50, "lon": 20},
            "eco": {"lat": 20, "lon": 10}
        }
    },
    "int": {"duration": 60},
    "avx": {"duration": 60}
}

if os.path.exists(SETTINGS_FILE):
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            settings = json.load(f)
    except Exception:
        settings = default_settings.copy()
else:
    settings = default_settings.copy()
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2)

# ==== Pygame ====
pygame.init()
WIDTH, HEIGHT = 900, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Cube Benchmark Menu")
font = pygame.font.SysFont("consolas", 24)
small = pygame.font.SysFont("consolas", 16)
clock = pygame.time.Clock()

benchmarks = ["CubeAVX", "CubeInt", "CubeRender", "Settings"]
core_modes = ["Single", "Multi"]
difficulty_modes = ["Extreme", "Balanced", "Eco"]

selected_bench = 0
selected_core = 0
selected_diff = 1
page = "main"
cursor_index = 0
input_mode = False
input_text = ""

# ==== Settings verisi ====
def build_settings_entries(s):
    e = [
        ("title", "Render Test"),
        ("render.duration", s["render"]["duration"]),
        ("render.profiles.extreme.lat", s["render"]["profiles"]["extreme"]["lat"]),
        ("render.profiles.extreme.lon", s["render"]["profiles"]["extreme"]["lon"]),
        ("render.profiles.balanced.lat", s["render"]["profiles"]["balanced"]["lat"]),
        ("render.profiles.balanced.lon", s["render"]["profiles"]["balanced"]["lon"]),
        ("render.profiles.eco.lat", s["render"]["profiles"]["eco"]["lat"]),
        ("render.profiles.eco.lon", s["render"]["profiles"]["eco"]["lon"]),
        ("title", "Integer Test"),
        ("int.duration", s["int"]["duration"]),
        ("title", "Floating (AVX) Test"),
        ("avx.duration", s["avx"]["duration"]),
        ("hint", "W/S: Move | A/D: Change | ENTER: Type | SPACE: Save | Q: Back")
    ]
    return e

entries = build_settings_entries(settings)

# ==== Menü çizimleri ====
def draw_main():
    screen.fill((10,10,10))
    title = font.render("== Cube Benchmark Menu ==", True, (0,255,255))
    screen.blit(title, (WIDTH//2 - title.get_width()//2, 50))
    for i,b in enumerate(benchmarks):
        col = (255,255,0) if i == selected_bench else (180,180,180)
        screen.blit(font.render(b, True, col), (120, 130 + i*60))
    screen.blit(small.render("W/S: Move | SPACE: Continue | ENTER: Settings", True, (160,160,160)), (60, 520))
    pygame.display.flip()

def draw_core():
    screen.fill((10,10,10))
    title = font.render(f"== {benchmarks[selected_bench]} Core Mode ==", True, (0,255,255))
    screen.blit(title, (WIDTH//2 - title.get_width()//2, 50))
    for i,c in enumerate(core_modes):
        col = (0,255,255) if i==selected_core else (100,100,100)
        screen.blit(font.render(c+" Core", True, col), (120, 130 + i*60))
    screen.blit(small.render("W/S: Move | Q: Back | SPACE: Continue", True, (160,160,160)), (60, 520))
    pygame.display.flip()

def draw_diff():
    screen.fill((10,10,10))
    title = font.render(f"== {benchmarks[selected_bench]} {core_modes[selected_core]} Profile ==", True, (0,255,255))
    screen.blit(title, (WIDTH//2 - title.get_width()//2, 50))
    for i,d in enumerate(difficulty_modes):
        col = (0,255,100) if i==selected_diff else (100,100,100)
        screen.blit(font.render(d, True, col), (120, 130 + i*60))
    screen.blit(small.render("W/S: Move | Q: Back | SPACE: Run", True, (160,160,160)), (60, 520))
    pygame.display.flip()

def draw_settings():
    screen.fill((8,8,8))
    title = font.render("== Settings ==", True, (0,200,255))
    screen.blit(title, (WIDTH//2 - title.get_width()//2, 40))
    y = 120
    for i,(k,v) in enumerate(entries):
        if k=="title":
            txt = font.render(v, True, (255,200,0))
            screen.blit(txt, (80, y))
            y += 40
        elif k=="hint":
            screen.blit(small.render(v, True, (150,150,150)), (80, y+20))
        else:
            col = (0,255,0) if i==cursor_index else (180,180,180)
            screen.blit(font.render(k.replace(".", " > "), True, col), (100, y))
            screen.blit(font.render(str(v), True, (200,255,200)), (600, y))
            y += 40

    if input_mode:
        pygame.draw.rect(screen, (30,30,30), (100, 540, 700, 40))
        screen.blit(font.render(f"Yeni değer girin: {input_text}", True, (0,255,255)), (110,545))

    pygame.display.flip()

# ==== Kaydet ====
def save_settings():
    global settings
    s = {"render":{"duration":settings["render"]["duration"],"profiles":{}},
         "int":{"duration":settings["int"]["duration"]},
         "avx":{"duration":settings["avx"]["duration"]}}
    for k,v in entries:
        if k.startswith("render.duration"):
            s["render"]["duration"]=int(v)
        elif k.startswith("render.profiles."):
            p=k.split("."); prof,field=p[2],p[3]
            if prof not in s["render"]["profiles"]: s["render"]["profiles"][prof]={}
            s["render"]["profiles"][prof][field]=int(v)
        elif k.startswith("int.duration"):
            s["int"]["duration"]=int(v)
        elif k.startswith("avx.duration"):
            s["avx"]["duration"]=int(v)
    settings=s
    with open(SETTINGS_FILE,"w",encoding="utf-8") as f:
        json.dump(settings,f,indent=2)

# ==== Test çalıştırıcı ====
def run_script():
    bench=benchmarks[selected_bench]
    if bench=="Settings": return
    core=core_modes[selected_core].lower()
    diff=difficulty_modes[selected_diff].lower()
    if bench=="CubeRender":
        lat=settings["render"]["profiles"][diff]["lat"]
        lon=settings["render"]["profiles"][diff]["lon"]
        dur=settings["render"]["duration"]
        cmd=[sys.executable,"CubeRender.py","--core",core,"--mode",diff,"--duration",str(dur),"--lat",str(lat),"--lon",str(lon)]
    elif bench=="CubeInt":
        dur=settings["int"]["duration"]
        cmd=[sys.executable,"CubeInt.py","--core",core,"--duration",str(dur)]
    elif bench=="CubeAVX":
        dur=settings["avx"]["duration"]
        cmd=[sys.executable,"CubeAVX.py","--core",core,"--duration",str(dur)]
    else:
        return
    subprocess.run(cmd)
    sys.exit()

# ==== Ana döngü ====
draw_main()
running=True
while running:
    for e in pygame.event.get():
        if e.type==pygame.QUIT:
            running=False

        elif e.type==pygame.KEYDOWN:
            # === Değer girişi açıkken ===
            if input_mode:
                if e.key == pygame.K_RETURN:
                    if input_text.isdigit():
                        key, val = entries[cursor_index]
                        entries[cursor_index] = (key, int(input_text))
                    input_mode = False
                    input_text = ""
                    draw_settings()
                elif e.key == pygame.K_ESCAPE:
                    input_mode = False
                    input_text = ""
                    draw_settings()
                elif e.key == pygame.K_BACKSPACE:
                    input_text = input_text[:-1]
                    draw_settings()
                elif e.unicode.isdigit():
                    input_text += e.unicode
                    draw_settings()
                continue

            # === Ana Menü ===
            if page=="main":
                if e.key in [pygame.K_w,pygame.K_UP]:
                    selected_bench=(selected_bench-1)%len(benchmarks); draw_main()
                elif e.key in [pygame.K_s,pygame.K_DOWN]:
                    selected_bench=(selected_bench+1)%len(benchmarks); draw_main()
                elif e.key==pygame.K_SPACE:
                    page="core" if benchmarks[selected_bench]!="Settings" else "settings"
                    if page=="core": draw_core()
                    else: draw_settings()
                elif e.key==pygame.K_RETURN:
                    page="settings"; draw_settings()

            elif page=="core":
                if e.key in [pygame.K_w,pygame.K_UP]:
                    selected_core=(selected_core-1)%len(core_modes); draw_core()
                elif e.key in [pygame.K_s,pygame.K_DOWN]:
                    selected_core=(selected_core+1)%len(core_modes); draw_core()
                elif e.key==pygame.K_q:
                    page="main"; draw_main()
                elif e.key==pygame.K_SPACE:
                    page="diff"; draw_diff()

            elif page=="diff":
                if e.key in [pygame.K_w,pygame.K_UP]:
                    selected_diff=(selected_diff-1)%len(difficulty_modes); draw_diff()
                elif e.key in [pygame.K_s,pygame.K_DOWN]:
                    selected_diff=(selected_diff+1)%len(difficulty_modes); draw_diff()
                elif e.key==pygame.K_q:
                    page="core"; draw_core()
                elif e.key==pygame.K_SPACE:
                    run_script()

            elif page=="settings":
                if e.key==pygame.K_q:
                    page="main"; draw_main()
                elif e.key==pygame.K_SPACE:
                    save_settings(); page="main"; draw_main()
                elif e.key in [pygame.K_w,pygame.K_UP]:
                    cursor_index=max(0,cursor_index-1); draw_settings()
                elif e.key in [pygame.K_s,pygame.K_DOWN]:
                    cursor_index=min(len(entries)-1,cursor_index+1); draw_settings()
                elif e.key in [pygame.K_a,pygame.K_LEFT,pygame.K_d,pygame.K_RIGHT]:
                    key,val=entries[cursor_index]
                    if isinstance(val,int):
                        delta=-1 if e.key in [pygame.K_a,pygame.K_LEFT] else 1
                        step=5 if "duration" in key else 1
                        new_val=max(1,val+delta*step)
                        entries[cursor_index]=(key,new_val)
                        draw_settings()
                elif e.key == pygame.K_RETURN:
                    key,val = entries[cursor_index]
                    if isinstance(val,int):
                        input_mode = True
                        input_text = ""
                        draw_settings()

    clock.tick(30)

pygame.quit()
