import pygame, sys, math, time, psutil, threading, queue
from math import sin, cos
from multiprocessing import Process, cpu_count, Queue, Manager


class CubeRender3D:
    def __init__(self, lat=50, lon=20, duration=60, idx=0, fps_queue=None):
        pygame.init()
        self.screen = pygame.display.set_mode((900, 600))
        pygame.display.set_caption(f"Render Çekirdek {idx+1}")
        self.clock = pygame.time.Clock()
        self.lat = lat
        self.lon = lon
        self.duration = duration
        self.running = True
        self.fps = 0
        self.frames = 0
        self.idx = idx
        self.queue = fps_queue

        self.camera_z = 4.0
        self.light_dir = [0.3, 0.4, 1.0]
        self.vertices = self.generate_sphere_points(lat, lon)

    def generate_sphere_points(self, lat, lon):
        pts = []
        for i in range(lat):
            theta = math.pi * i / (lat - 1)
            for j in range(lon):
                phi = 2 * math.pi * j / (lon - 1)
                x = math.sin(theta) * math.cos(phi)
                y = math.cos(theta)
                z = math.sin(theta) * math.sin(phi)
                pts.append([x, y, z])
        return pts

    def project(self, x, y, z):
        fov = 400
        scale = fov / (self.camera_z - z)
        px = int(450 + x * scale)
        py = int(300 - y * scale)
        return px, py

    def run(self):
        start = time.time()
        angle_x, angle_y = 0.0, 0.0
        font = pygame.font.SysFont("consolas", 20)

        while self.running and (time.time() - start < self.duration):
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    self.running = False
                    return

            self.screen.fill((0, 0, 0))
            cosx, sinx = cos(angle_x), sin(angle_x)
            cosy, siny = cos(angle_y), sin(angle_y)

            for vx, vy, vz in self.vertices:
                x = vx * cosy + vz * siny
                z = -vx * siny + vz * cosy
                y = vy * cosx - z * sinx
                z = vy * sinx + z * cosx

                dot = x * self.light_dir[0] + y * self.light_dir[1] + z * self.light_dir[2]
                brightness = max(0.1, min(1.0, dot))
                color = (int(80 * brightness), int(180 * brightness), int(255 * brightness))

                px, py = self.project(x, y, z)
                if 0 <= px < 900 and 0 <= py < 600:
                    self.screen.set_at((px, py), color)

            self.fps = self.clock.get_fps()
            self.frames += 1

            fps_text = font.render(f"FPS: {self.fps:.1f}", True, (0,255,0))
            self.screen.blit(fps_text, (10, 10))

            if self.queue:
                self.queue.put((self.idx, self.fps, self.frames))

            pygame.display.flip()
            angle_x += 0.02
            angle_y += 0.03
            self.clock.tick()

        pygame.quit()


def task_monitor(duration, fps_queue, core_count):
    pygame.init()
    scr = pygame.display.set_mode((700, 400))
    pygame.display.set_caption("Cube Benchmark Monitor")
    font = pygame.font.SysFont("consolas", 20)
    clock = pygame.time.Clock()
    start = time.time()

    fps_data = {i: (0, 0) for i in range(core_count)}  # idx: (fps, frames)
    scroll = 0

    while time.time() - start < duration:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_w: scroll = max(0, scroll - 1)
                if e.key == pygame.K_s: scroll = min(core_count - 8, scroll + 1)

        
        while not fps_queue.empty():
            idx, fps, frames = fps_queue.get()
            fps_data[idx] = (fps, frames)

        
        cpu_perc = psutil.cpu_percent(percpu=True)
        ram = psutil.virtual_memory()

        avg_fps = sum(v[0] for v in fps_data.values()) / max(1, len(fps_data))
        total_frames = sum(v[1] for v in fps_data.values())

        scr.fill((15, 15, 15))
        scr.blit(font.render(f"Avg FPS: {avg_fps:.1f}", True, (0,255,255)), (20, 10))
        scr.blit(font.render(f"Tatal Frame: {total_frames}", True, (255,255,0)), (320, 10))
        scr.blit(font.render(f"RAM: {ram.percent:.1f}% ({ram.used//(1024**2)} MB)", True, (0,255,100)), (20, 40))

        y = 80
        for i in range(scroll, min(core_count, scroll + 8)):
            c = cpu_perc[i]
            f = fps_data[i][0]
            scr.blit(font.render(f"Core {i+1:02d}: {c:5.1f}%  | FPS {f:5.1f}", True, (255,255,255)), (30, y))
            y += 30

        pygame.display.flip()
        clock.tick(2)

    pygame.quit()


def worker(lat, lon, duration, idx, q):
    CubeRender3D(lat, lon, duration, idx, q).run()

def run_multi(lat, lon, duration):
    core_count = cpu_count()
    q = Queue()
    threading.Thread(target=task_monitor, args=(duration, q, core_count), daemon=True).start()

    procs = []
    for i in range(core_count):
        p = Process(target=worker, args=(lat, lon, duration, i, q))
        p.start()
        procs.append(p)
    for p in procs:
        p.join()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--core", default="single")
    parser.add_argument("--mode", default="balanced")
    parser.add_argument("--duration", type=int, default=60)
    parser.add_argument("--lat", type=int, default=50)
    parser.add_argument("--lon", type=int, default=20)
    args = parser.parse_args()

    print(f"[CubeRender] Starting ({args.core} | {args.mode} | {args.duration}s | lat={args.lat}, lon={args.lon})")

    if args.core == "multi":
        run_multi(args.lat, args.lon, args.duration)
    else:
        q = Queue()
        threading.Thread(target=task_monitor, args=(args.duration, q, 1), daemon=True).start()
        CubeRender3D(args.lat, args.lon, args.duration, 0, q).run()
