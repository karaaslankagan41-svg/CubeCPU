import math, time, sys, pygame

def avx_test(duration=60):
    start = time.time()
    total = 0
    while time.time() - start < duration:
        total += math.sqrt(math.sin(total+1)**2 + math.cos(total+2)**2)
    print(f"AVX test complete ({duration}s) total={int(total)}")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--core", default="single")
    parser.add_argument("--duration", type=int, default=60)
    args = parser.parse_args()
    avx_test(args.duration)
