import argparse, time, math, os, sys
from multiprocessing import Process, Queue, cpu_count, set_start_method
import pygame, psutil

def worker(idx, duration, q):
    try:
        psutil.Process(os.getpid()).cpu_affinity([idx])
    except Exception:
        pass
    end = time.time() + duration
    x = 1.23456789 + idx * 0.00001
    total = 0
    last_time = time.time()
    last_sent = time.time()
    ops_since_last = 0
    while time.time() < end:
        for _ in range(200000):
            x = (math.sin(x) + math.cos(x*1.0000001)) * (x + 1.0000001)
            x = x - math.floor(x/3.14159) * 3.14159
            total += 1
            ops_since_last += 1
        now = time.time()
        if now - last_sent >= 1.0:
            try:
                q.put(('update', idx, ops_since_last, total))
            except:
                pass
            ops_since_last = 0
            last_sent = now
    try:
        q.put(('done', idx, ops_since_last, total))
    except:
        pass

def monitor(workers, duration, q):
    pygame.init()
    W,H=800,550
    screen = pygame.display.set_mode((W,H))
    pygame.display.set_caption("CubeAVX Benchmark Monitor")
    font = pygame.font.SysFont("consolas",18)
    big = pygame.font.SysFont("consolas",22,bold=True)
    clock = pygame.time.Clock()
    start = time.time()
    data = {i:{"sec":0,"total":0,"done":False} for i in range(workers)}
    running=True
    while running:
        now = time.time()
        remaining = max(0.0, start + duration - now)
        while True:
            try:
                msg=q.get_nowait()
            except:
                break
            if msg[0] in ("update","done"):
                _,idx,sec,total = msg
                data[idx]["sec"]=int(sec)
                data[idx]["total"]=int(total)
                if msg[0]=="done": data[idx]["done"]=True
        for e in pygame.event.get():
            if e.type==pygame.QUIT: running=False
        cpu=psutil.cpu_percent(percpu=True)
        ram=psutil.virtual_memory()
        screen.fill((12,12,15))
        screen.blit(big.render("AVX Stress Monitor",True,(0,255,255)),(20,10))
        screen.blit(font.render(f"Time Left: {remaining:5.1f}s",True,(220,220,220)),(20,45))
        total_ops=sum(v["total"] for v in data.values())
        avg_ops=sum(v["sec"] for v in data.values())/max(1,len(data))
        screen.blit(font.render(f"Total Ops: {total_ops}",True,(200,255,200)),(250,45))
        screen.blit(font.render(f"Avg Ops/s per core: {avg_ops:.0f}",True,(200,255,200)),(520,45))
        screen.blit(font.render(f"RAM: {ram.percent:.1f}%  ({ram.used//(1024**2)} MB)",True,(255,230,130)),(20,70))
        y=110
        for i in range(workers):
            sec=data[i]["sec"]; tot=data[i]["total"]; done=data[i]["done"]
            cusage = cpu[i] if i < len(cpu) else 0
            status="done" if done else "running"
            txt=f"Core {i:02d} | CPU% {cusage:5.1f} | ops/s {sec:7d} | total {tot:10d} | {status}"
            col=(180,255,200) if not done else (130,130,130)
            screen.blit(font.render(txt,True,col),(20,y))
            y+=26
        pygame.display.flip()
        clock.tick(8)
        if remaining<=0 or all(v["done"] for v in data.values()):
            running=False
    pygame.quit()
    return sum(v["total"] for v in data.values())

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--core",choices=["single","multi"],required=True)
    parser.add_argument("--duration",type=int,required=True)
    a=parser.parse_args()
    try: set_start_method("spawn")
    except: pass
    cores=1 if a.core=="single" else cpu_count()
    q=Queue()
    procs=[Process(target=worker,args=(i,a.duration,q)) for i in range(cores)]
    for p in procs: p.start()
    total=monitor(cores,a.duration,q)
    for p in procs:
        try:
            p.join(timeout=0.5)
            if p.is_alive(): p.terminate()
        except:
            pass
    print(f"AVX Stress Complete | Cores: {cores} | Duration: {a.duration}s | TotalOps: {total}")
