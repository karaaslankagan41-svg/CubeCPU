import os, sys, ctypes, subprocess, pygame, json, traceback, time
import multiprocessing as mp 
import psutil 
import platform
import math 
from math import sin, cos
from multiprocessing import Process, cpu_count, Queue, Manager
import threading 

def render_worker_unified(lat, lon, duration, idx, results_shared):
    try:
        if idx == 0 and pygame.get_init() == False:
            pygame.init()
            
        clock = pygame.time.Clock()
        running = True
        frames = 0
        
        is_visual = (idx == 0)
        if is_visual:
            WINDOW_W, WINDOW_H = 300, 300
            screen = pygame.display.set_mode((WINDOW_W, WINDOW_H)) 
            pygame.display.set_caption(f"CubeRender Core {idx+1} (Visual Proof)")
            pygame.event.set_blocked(None)
            pygame.event.set_allowed([pygame.QUIT]) 

        camera_z = 4.0
        light_dir = [0.3, 0.4, 1.0]
        
        lat_count, lon_count = lat, lon
        pts = []
        for i in range(lat_count):
            theta = math.pi * i / (lat_count - 1)
            for j in range(lon_count):
                phi = 2 * math.pi * j / (lon_count - 1)
                x = math.sin(theta) * math.cos(phi)
                y = math.cos(theta)
                z = math.sin(theta) * math.sin(phi)
                pts.append([x, y, z])
        vertices = pts
        
        def project(x, y, z):
            fov = 200
            scale = fov / (camera_z - z)
            px = int(150 + x * scale) if is_visual else 0 
            py = int(150 - y * scale) if is_visual else 0
            return px, py
        
        start = time.time()
        angle_x, angle_y = 0.0, 0.0
        
        base_index = idx * 2
        
        while running and (time.time() - start < duration):
            
            if is_visual:
                for e in pygame.event.get():
                    if e.type == pygame.QUIT:
                        running = False
                        break
            
            cosx, sinx = cos(angle_x), sin(angle_x)
            cosy, siny = cos(angle_y), sin(angle_y)

            if is_visual: screen.fill((0, 0, 0))
            
            for vx, vy, vz in vertices:
                x = vx * cosy + vz * siny
                z = -vx * siny + vz * cosy
                y = vy * cosx - z * sinx
                z = vy * sinx + z * cosx

                dot = x * light_dir[0] + y * light_dir[1] + z * light_dir[2]
                brightness = max(0.1, min(1.0, dot))
                color = (int(80 * brightness), int(180 * brightness), int(255 * brightness))

                px, py = project(x, y, z)
                
                if is_visual and 0 <= px < WINDOW_W and 0 <= py < WINDOW_H:
                    screen.set_at((px, py), color)
                
            frames += 1

            angle_x += 0.02
            angle_y += 0.03
            
            if is_visual: pygame.display.flip() 
            
            fps = clock.get_fps()
            results_shared[base_index] = fps      
            results_shared[base_index + 1] = frames 
            
            clock.tick()
            
        results_shared[base_index] = 0.0
        
    except Exception:
        results_shared[base_index] = -1.0 
    finally:
        if is_visual and pygame.get_init():
            pygame.quit()
        sys.exit()

def benchmark_worker_int_loop(core_idx, loop_value, duration, results_shared):
    base_val = 123456789 + core_idx * 1000
    x1 = base_val
    x2 = base_val + 11
    x3 = base_val + 23
    x4 = base_val + 37

    MASK_64 = 0xFFFFFFFFFFFFFFFF
    
    start_time = time.time()
    
    base_index = core_idx * 2
    
    results_shared[base_index] = 0.0      
    results_shared[base_index + 1] = 0.0  
    
    while time.time() - start_time < duration:
        
        for i in range(1, int(loop_value) + 1):
            
            x1 ^= (x1 << 13) & MASK_64
            x1 = (x1 * 6364136223846793005 + i) & MASK_64
            x1 ^= (x1 >> 17)
            x1 = ((x1 << 29) | (x1 >> 35)) & MASK_64
            
            x2 = (x2 + 0xDEEADBEAF) & MASK_64
            x2 ^= (x2 >> 19)
            x2 = (x2 * 0x7654321 + i) & MASK_64
            x2 = (x2 - 0x1234567) & MASK_64
            
            x3 = (x3 << 7) & MASK_64
            x3 = (x3 | (x3 >> 57)) & MASK_64 
            x3 = (x3 ^ i) & MASK_64
            x3 = (x3 * 0x42424242) & MASK_64
            
            x4 = (x4 * 0x900DDEBEEF + i) & MASK_64
            x4 ^= (x4 >> 31)
            x4 = (x4 + 0xAABBCCDD) & MASK_64
            x4 = (x4 ^ x3) & MASK_64 
            
        results_shared[base_index] += 1.0 
        results_shared[base_index + 1] = loop_value 
        
    results_shared[base_index + 1] = 0.0 

def benchmark_worker_avx(core_idx, loop_value, duration, results_shared):
    start_time = time.time()
    
    N = int(loop_value / 10)
    
    a = [float(i + core_idx * 0.1) for i in range(N)]
    b = [float(i * 0.001) for i in range(N)]
    c = [float(i * 0.0001) for i in range(N)]
    
    total_iterations = 0
    
    base_index = core_idx * 2
    
    results_shared[base_index] = 0.0
    results_shared[base_index + 1] = 0.0 
    
    while time.time() - start_time < duration:
        
        for i in range(N):
            a[i] = a[i] * b[i] + c[i]
            b[i] = math.sqrt(a[i]) 
            c[i] = b[i] + 1.0
            a[i] = a[i] * 0.999 
            b[i] = c[i] / 0.5 
            
            total_iterations += 1

        flops_in_block = N * 6
        
        results_shared[base_index] += flops_in_block
        
        elapsed = time.time() - start_time
        if elapsed > 0:
            current_gflops = (results_shared[base_index] / elapsed) / 1_000_000_000 
            results_shared[base_index + 1] = current_gflops 
        
    results_shared[base_index + 1] = 0.0 

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def get_cpu_info():
    try:
        if platform.system() == "Windows":
            import winreg
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
            cpu_name, _ = winreg.QueryValueEx(key, "ProcessorNameString")
            return cpu_name.strip()
        else:
            return platform.processor() or "Unknown CPU Model"
    except Exception:
        return "Unknown CPU Model"
        
def save_settings(settings, settings_file):
    try:
        with open(settings_file,"w") as f:
            json.dump(settings,f,indent=4)
    except Exception as e:
        with open("crash_log.txt","a") as f:
            f.write(f"\n--- Save Error ---\n{time.ctime()}\n{str(e)}\n")

settings_file = "settings.json"

default_settings = {
    "render":{
        "eco":{"lat":20,"lon":10,"time":30},
        "balanced":{"lat":50,"lon":20,"time":60},
        "extreme":{"lat":100,"lon":50,"time":90}
    },
    "intloop":{ 
        "standard":{"loop_value":600000,"time":60},
        "extended":{"loop_value":600000,"time":180}
    },
    "avx":{ 
        "low":{"loop_value":1000000,"time":60},
        "high":{"loop_value":5000000,"time":120}
    }
}

if os.path.exists(settings_file):
    try:
        with open(settings_file,"r") as f:
            settings = json.load(f)
            if "int" in settings: del settings["int"]
            if "intnew" in settings: del settings["intnew"]
            settings = {**default_settings, **settings} 
    except json.JSONDecodeError:
        settings = default_settings.copy()
else:
    settings = default_settings.copy()
    
save_settings(settings, settings_file)

settings_keys = ["render", "intloop", "avx"] 

benchmark_modes = {
    "CubeRender":["Eco","Balanced","Extreme"],
    "CubeIntLoop":["Standard","Extended"],
    "CubeAVX":["Low","High"] 
}
benchmark_map = {
    "render": "CubeRender",
    "intloop": "CubeIntLoop",
    "avx": "CubeAVX" 
}

WIDTH, HEIGHT = 950, 650
CPU_MODEL = get_cpu_info()
screen = None
font = None
small_font = None
clock = None
benchmarks = ["CubeMonitor", "CubeIntLoop", "CubeRender", "CubeAVX", "Settings", "CubeMenu"] 
selected_bench = 0
open_tabs = ["CubeMonitor", "CubeMenu"]
active_tab = "CubeMonitor"
running_benchmark = None 
results_list = None 
benchmark_process = None 
running = False 
scroll_offset = 0 
settings_scroll_offset = 0 
selected_diff = 0
menu_state = "MAIN_LIST" 

def draw_logo(surface):
    cx,cy = WIDTH//2,50
    size = 60
    pygame.draw.rect(surface,(0,180,255),(cx-size//2,cy,size,size),4)
    pygame.draw.line(surface,(0,120,255),(cx-size//2,cy),(cx+size//2,cy),2)
    pygame.draw.line(surface,(0,120,255),(cx-size//2,cy),(cx-size//2,cy+size),2)
    pygame.draw.line(surface,(0,100,255),(cx-size//2,cy),(cx,cy-20),2)
    pygame.draw.line(surface,(0,100,255),(cx+size//2,cy),(cx,cy-20),2)

def draw_tabs():
    x_offset=10
    tab_height=40
    
    is_render_running = (isinstance(benchmark_process, list) and 
                         any(p.is_alive() for p in benchmark_process) and 
                         running_benchmark and running_benchmark.get('type') == 'RENDER')
    
    is_intloop_running = (isinstance(benchmark_process, list) and 
                         any(p.is_alive() for p in benchmark_process) and 
                         running_benchmark and running_benchmark.get('type') == 'INTLOOP')
                         
    is_avx_running = (isinstance(benchmark_process, list) and 
                         any(p.is_alive() for p in benchmark_process) and 
                         running_benchmark and running_benchmark.get('type') == 'AVX')
    
    for tab_name in open_tabs:
        color_bg = (50, 50, 50)

        if tab_name == active_tab:
            color_bg = (0, 100, 200) 
        elif tab_name == "CubeRender" and is_render_running:
            color_bg = (0, 150, 50)
        elif tab_name == "CubeIntLoop" and is_intloop_running:
            color_bg = (255, 120, 0)
        elif tab_name == "CubeAVX" and is_avx_running: 
            color_bg = (180, 0, 255)

        pygame.draw.rect(screen, color_bg, (x_offset, 10, 150, tab_height))
        screen.blit(small_font.render(tab_name, True, (255, 255, 255)), (x_offset + 10, 20))
        x_offset += 160

def get_lines_for_category(k):
    lines=[]
    mode_key = benchmark_map.get(k)
    
    if mode_key == "CubeRender":
        for profile in benchmark_modes[mode_key]:
            lines.append(("lat",profile.lower()))
            lines.append(("lon",profile.lower()))
            lines.append(("time",profile.lower()))
    
    elif mode_key == "CubeIntLoop":
        for profile in benchmark_modes[mode_key]:
            lines.append(("loop_value",profile.lower()))
            lines.append(("time",profile.lower()))
            
    elif mode_key == "CubeAVX":
        for profile in benchmark_modes[mode_key]:
            lines.append(("loop_value",profile.lower()))
            lines.append(("time",profile.lower()))

    return lines

def get_float_input(prompt, initial="0.0"):
    input_active = True
    user_text = str(initial)
    font_input = pygame.font.SysFont("consolas",24)
    clock_input = pygame.time.Clock()
    temp_tick = 60
    
    while input_active:
        screen.fill((20,20,20))
        draw_logo(screen)
        draw_tabs()
        screen.blit(font_input.render(prompt, True, (255,255,255)), (50,300))
        pygame.draw.rect(screen,(50,50,50),(50,350,200,30))
        screen.blit(font_input.render(user_text, True, (0,255,0)), (55,355))
        
        if int(time.time() * 2) % 2 == 0:
            cursor_pos = font_input.size(user_text)[0]
            pygame.draw.line(screen, (0,255,0), (55 + cursor_pos, 355), (55 + cursor_pos, 380), 2)

        pygame.display.flip()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                global running
                running=False
                return None 
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    try:
                        return float(user_text)
                    except:
                        return None
                elif event.key == pygame.K_BACKSPACE:
                    user_text = user_text[:-1]
                elif event.unicode in "0123456789.":
                    user_text += event.unicode
                elif event.key == pygame.K_ESCAPE:
                    return None
        clock_input.tick(temp_tick)

def draw_settings_tab():
    global selected_diff, settings_scroll_offset
    screen.fill((10,10,10))
    draw_logo(screen)
    draw_tabs()
    screen.blit(font.render("== Settings (Press SPACE to Save) ==", True,(0,255,255)),(WIDTH//2 - 220,120))
    
    # Yerel değişken tanımlamaları burada yapılıyor
    SETTINGS_CONTENT_START_Y = 200
    SETTINGS_CONTENT_END_Y = 580
    ROW_HEIGHT = 25
    HEADER_SPACING = 35 
    SETTINGS_VIEWPORT_LINES = 14
    
    editable_lines = []
    
    line_y_positions = []
    y_current_absolute = 0
    
    for k in settings_keys:
        y_current_absolute += HEADER_SPACING
        lines = get_lines_for_category(k)
        for line_data in lines:
            editable_lines.append((k, line_data))
            line_y_positions.append(y_current_absolute)
            y_current_absolute += ROW_HEIGHT
        y_current_absolute += ROW_HEIGHT 
    
    total_lines = len(editable_lines)
    
    if total_lines > 0:
        if selected_diff < settings_scroll_offset:
            settings_scroll_offset = selected_diff
        elif selected_diff >= settings_scroll_offset + SETTINGS_VIEWPORT_LINES:
            settings_scroll_offset = selected_diff - SETTINGS_VIEWPORT_LINES + 1
        
        max_scroll = max(0, total_lines - SETTINGS_VIEWPORT_LINES)
        settings_scroll_offset = max(0, min(settings_scroll_offset, max_scroll))
    else:
        settings_scroll_offset = 0
        
    y_shift_pixels = 0
    if total_lines > 0 and settings_scroll_offset < len(line_y_positions):
        # Kaydırma ofseti, ilk görünür ayar satırının başlangıcını 0'a hizalar.
        # Bu, başlıkları da içerdiği için, y_current_absolute'u da başlangıç değeri olan 0'a çekmek gerekiyor.
        # line_y_positions[settings_scroll_offset] değeri, seçilen satıra gelene kadar geçen mutlak yüksekliği verir.
        # Bu değeri çıkarırsak, seçilen satır listenin en üstüne kayar (gerekirse).
        
        # Daha doğru bir kaydırma için, header'ların ve padding'lerin de hesaba katılması gerekiyor.
        # En basit yaklaşımla: Seçilen satırın mutlak Y pozisyonu (line_y_positions) ile viewport başlangıcı arasındaki fark.
        
        
        # Mutlak y değerini sıfırla ve yeniden hesapla (sadece kaydırma için)
        y_absolute_for_shift = 0
        editable_counter_for_shift = 0
        found_scroll_point = False
        
        for k in settings_keys:
            y_absolute_for_shift += HEADER_SPACING
            lines = get_lines_for_category(k)
            for _ in lines:
                if editable_counter_for_shift == settings_scroll_offset:
                    y_shift_pixels = SETTINGS_CONTENT_START_Y - (SETTINGS_CONTENT_START_Y + y_absolute_for_shift)
                    found_scroll_point = True
                    break
                y_absolute_for_shift += ROW_HEIGHT
                editable_counter_for_shift += 1
            if found_scroll_point: break
            y_absolute_for_shift += ROW_HEIGHT 
        
        # Bu fix sadece satırların kaydırılması içindi. Başlığı da içeren doğru y_shift'i bulmak zor.
        # Önceki versiyonumuzu geri alalım ve sadece offset'i kullanalım, çizim döngüsü içinde başlıkları da kontrol ederek.
        
        # En basit ve en garantili yöntem: İlk görünen ayarlanabilir satırın Y konumu, görüntüleme alanının başlangıcına kaydırılır.
        y_initial_scroll_point = 0
        current_line_index = 0
        for k in settings_keys:
            y_initial_scroll_point += HEADER_SPACING
            lines = get_lines_for_category(k)
            for _ in lines:
                if current_line_index == settings_scroll_offset:
                    y_shift_pixels = -y_initial_scroll_point # Başlık dahil tüm bu mesafeyi yukarı kaydır
                    break
                y_initial_scroll_point += ROW_HEIGHT
                current_line_index += 1
            if y_shift_pixels != 0:
                 break
            y_initial_scroll_point += ROW_HEIGHT
        
    pygame.draw.rect(screen, (30, 30, 30), (45, SETTINGS_CONTENT_START_Y, WIDTH - 90, SETTINGS_CONTENT_END_Y - SETTINGS_CONTENT_START_Y), 0)
    
    y_current_absolute = 0 
    editable_counter = 0

    for k in settings_keys: 
        header_text = f"[{benchmark_map[k]}]"
        
        y_current_absolute += HEADER_SPACING
        
        current_y_drawn = SETTINGS_CONTENT_START_Y + y_current_absolute + y_shift_pixels
        
        # Görünüm alanı kontrolü
        if SETTINGS_CONTENT_START_Y <= current_y_drawn < SETTINGS_CONTENT_END_Y:
            screen.blit(font.render(header_text, True, (255, 255, 0)), (50, current_y_drawn))
            
        lines = get_lines_for_category(k)
        
        for line in lines:
            typ, key = line
            val = settings[k][key][typ]
            val_str = str(int(val)) if abs(val - int(val)) < 0.001 else f"{val:.2f}"
            
            if typ == "loop_value":
                text = f"{key.capitalize()} Loop Size: {int(val):,}"
            else:
                text = f"{key.capitalize()} {typ.capitalize()}: {val_str}"
            
            color = (255, 100, 255) if editable_counter == selected_diff else (180, 180, 180)
            
            y_current_absolute += ROW_HEIGHT
            current_y_drawn = SETTINGS_CONTENT_START_Y + y_current_absolute + y_shift_pixels

            # Görünüm alanı kontrolü
            if SETTINGS_CONTENT_START_Y <= current_y_drawn < SETTINGS_CONTENT_END_Y:
                screen.blit(font.render(text, True, color), (70, current_y_drawn))
            
            editable_counter += 1
            
        y_current_absolute += ROW_HEIGHT 
        
    pygame.draw.rect(screen, (70, 70, 70), (45, SETTINGS_CONTENT_START_Y, WIDTH - 90, SETTINGS_CONTENT_END_Y - SETTINGS_CONTENT_START_Y), 1)

    screen.blit(small_font.render("W/S select line | D edit value | SPACE save | ESC back",True,(150,150,150)),(20,600))
    pygame.display.flip()

def handle_settings_keyboard(event):
    global selected_diff, menu_state, settings_scroll_offset
    
    editable_lines = []
    for k in settings_keys:
        lines = get_lines_for_category(k)
        for line in lines:
            editable_lines.append((k,line))
    total_lines = len(editable_lines)
    
    SETTINGS_VIEWPORT_LINES = 14 

    if event.key in [pygame.K_w]:
        selected_diff = (selected_diff - 1) % total_lines
        if total_lines > SETTINGS_VIEWPORT_LINES and selected_diff < settings_scroll_offset:
            settings_scroll_offset = selected_diff
            
    elif event.key in [pygame.K_s]:
        selected_diff = (selected_diff + 1) % total_lines
        if total_lines > SETTINGS_VIEWPORT_LINES and selected_diff >= settings_scroll_offset + SETTINGS_VIEWPORT_LINES:
            settings_scroll_offset = selected_diff - SETTINGS_VIEWPORT_LINES + 1
            
    elif event.key in [pygame.K_d]:
        if total_lines == 0: return
        k, line = editable_lines[selected_diff]
        typ,key = line
        current_val = settings[k][key][typ]
        
        prompt_text = f"Enter new value for {key.capitalize()} {typ.capitalize()} ({k}):"
        
        new_val = get_float_input(prompt_text,str(current_val))
        
        if new_val is not None:
            settings[k][key][typ] = max(1,new_val)
            save_settings(settings, settings_file)
            
    elif event.key in [pygame.K_SPACE, pygame.K_RETURN]:
        save_settings(settings, settings_file)
        
    elif event.key==pygame.K_ESCAPE:
        menu_state="MAIN_LIST"
        selected_diff = 0
        settings_scroll_offset = 0

def draw_main_menu():
    screen.fill((10,10,10))
    draw_logo(screen)
    draw_tabs()
    screen.blit(font.render("== Cube Benchmark Menu ==",True,(0,255,255)),(WIDTH//2 - 160,120))
    
    menu_items = [b for b in benchmarks if b not in ["CubeMonitor", "CubeMenu"]]
    
    y_start = 200
    for i,b in enumerate(menu_items):
        menu_index = benchmarks.index(b)
        color = (255,255,0) if menu_index==selected_bench else (180,180,180)
        screen.blit(font.render(b,True,color),(100,y_start+i*60))
        
        info_text = ""
        if menu_index==selected_bench:
            if b == "CubeIntLoop":
                info_text = "Multi-Threaded INTEGER/BITWISE Test (Fixed Loop Size)"
            elif b == "CubeRender":
                info_text = "Configurable Multi-Threaded 3D Rendering FPU Test"
            elif b == "CubeAVX":
                info_text = "Multi-Threaded High-Load VECTOR/SIMD Float Test (GFLOPS)"
            elif b == "Settings":
                info_text = "Configure parameters for tests"

        if info_text:
              screen.blit(small_font.render(info_text,True,(255,100,100)),(300,y_start+i*60))
              
    screen.blit(small_font.render("W/S select | SPACE / ENTER to continue | ESC to Monitor",True,(150,150,150)),(40,600))
    pygame.display.flip()

def draw_diff_menu():
    global selected_diff
    screen.fill((10,10,10))
    draw_logo(screen)
    draw_tabs()
    bench_name = benchmarks[selected_bench]
    
    if bench_name == "Settings":
        return 

    screen.blit(font.render(f"== {bench_name} Profile ==",True,(0,255,255)),(WIDTH//2 - 160,120))
    modes = benchmark_modes[bench_name]
    
    y_pos = 200
    for i,d in enumerate(modes):
        color=(0,255,100) if i==selected_diff else (100,100,100)
        screen.blit(font.render(d,True,color),(100,y_pos))
        
        mode_key = d.lower()
        info = "Error: Unknown Mode"
        
        if bench_name == "CubeRender":
            s = settings["render"][mode_key]
            info = f"LAT:{s['lat']} LON:{s['lon']} TIME:{s['time']}s (FPU)"
        elif bench_name == "CubeIntLoop":
            s = settings["intloop"][mode_key]
            info = f"LOOP SIZE: {s['loop_value']:,} TIME: {s['time']}s (INT/BITWISE)"
        elif bench_name == "CubeAVX": 
            s = settings["avx"][mode_key]
            info = f"LOOP SIZE: {s['loop_value']:,} TIME: {s['time']}s (VECTOR FLOAT)"
            
        screen.blit(small_font.render(info,True,(150,150,150)),(300, y_pos+5))
        y_pos += 60
        
    screen.blit(small_font.render("W/S select | SPACE / ENTER to run | ESC to go back", True, (150,150,150)), (40,600))
    pygame.display.flip()

def draw_monitor_tab():
    global scroll_offset
    screen.fill((20,20,20))
    draw_logo(screen)
    draw_tabs()
    
    cpu_loads = psutil.cpu_percent(interval=None, percpu=True) 
    
    system_load = sum(cpu_loads) / len(cpu_loads) if cpu_loads else 0.0
    
    title_text = "== CubeMonitor (Real-time CPU Usage) =="
    screen.blit(font.render(title_text,True,(0,255,100)),(WIDTH//2 - len(title_text)*6,120))
    
    screen.blit(font.render(f"CPU Model: {CPU_MODEL}", True, (0,150,255)), (50, 180))
    screen.blit(font.render(f"Logical Cores: {len(cpu_loads)}", True, (0,150,255)), (50, 210))
    screen.blit(font.render(f"Overall Load: {system_load:.1f}%", True, (255,255,0)), (50, 240))
    
    y = 280
    row_height = 25
    visible_cores = 10 

    max_scroll = max(0, len(cpu_loads) - visible_cores)
    scroll_offset = max(0, min(scroll_offset, max_scroll))

    screen.blit(small_font.render("--- Per-Core Utilization (W/S to Scroll) ---", True, (150,150,150)), (50, y))
    y += row_height + 5
    
    for i in range(visible_cores):
        idx = scroll_offset + i
        if idx >= len(cpu_loads):
            break
            
        load = cpu_loads[idx]
        color = (255,255,0) if load > 80 else (0,255,0) if load > 30 else (100,100,255)
        
        usage_text = f"Core {idx:02}: {load:.1f}%"
        
        screen.blit(small_font.render(usage_text, True, color),(50,y))
        
        bar_width = int(load * 3)
        pygame.draw.rect(screen, color, (200, y + 2, bar_width, 18), 0, 3)
        pygame.draw.rect(screen, (70,70,70), (200, y + 2, 300, 18), 1, 3)
        
        y += row_height
    
    if len(cpu_loads) > visible_cores:
        scroll_indicator = f"Displaying {scroll_offset+1}-{min(len(cpu_loads), scroll_offset+i+1)} of {len(cpu_loads)}"
        screen.blit(small_font.render(scroll_indicator, True, (255,150,0)), (50, HEIGHT - 50))
    
    pygame.display.flip()

def draw_intloop_tab(tab):
    global scroll_offset
    screen.fill((20,20,20))
    draw_logo(screen)
    draw_tabs()
    
    is_running = isinstance(benchmark_process, list) and any(p.is_alive() for p in benchmark_process)
    
    title_text = f"== {tab['name']} - {'RUNNING' if is_running else 'FINISHED'} =="
    title_color = (255,120,0) if is_running else (0,150,255) 
    screen.blit(font.render(title_text,True,title_color),(WIDTH//2 - len(title_text)*6,120))
    
    elapsed_time = time.time() - tab['start']
    remaining = max(0, tab['duration'] - elapsed_time)
    
    system_load = psutil.cpu_percent(interval=None) if is_running else 0.0
    screen.blit(small_font.render(f"CPU: {CPU_MODEL}", True, (0,150,255)), (20, 160))
    screen.blit(small_font.render(f"Overall Load: {system_load:.1f}%", True, (0,255,0)), (20, 180))
    
    time_text = f"Time: {elapsed_time:.1f}/{tab['duration']}s ({remaining:.1f}s left)"
    screen.blit(font.render(time_text, True, (255,255,0)), (WIDTH - 300, 160))
    
    y=210
    row_height = 25
    visible_cores = 12 

    max_scroll = max(0, tab['cores'] - visible_cores)
    scroll_offset = max(0, min(scroll_offset, max_scroll))

    total_blocks = 0.0
    total_mips = 0.0
    loop_value = tab['loop_value']
    
    M_DIVISOR = 1_000_000
    
    if results_list is not None: 
        for idx_agg in range(tab['cores']):
            base_index = idx_agg * 2
            try:
                total_blocks_core = results_list[base_index] 
            except IndexError:
                total_blocks_core = 0.0
            
            mips_core = (total_blocks_core * loop_value / elapsed_time / M_DIVISOR) if elapsed_time > 0 and elapsed_time < tab['duration'] else 0
            
            total_mips += mips_core
            total_blocks += total_blocks_core

        for i in range(visible_cores):
            idx = scroll_offset + i
            if idx >= tab['cores']:
                break
                
            base_index = idx * 2
            
            try:
                total_blocks_core = results_list[base_index]
                blocks_per_second = total_blocks_core / elapsed_time if elapsed_time > 0 else 0
                
            except IndexError:
                total_blocks_core, blocks_per_second = 0.0, 0.0
            
            mips_core_display = (total_blocks_core * loop_value / elapsed_time / M_DIVISOR) if elapsed_time > 0 and elapsed_time < tab['duration'] else 0
            
            rate_text = f"C{idx:02} | Current Blocks/s: {blocks_per_second:.2f}"
            total_text = f"| Total Blocks: {int(total_blocks_core):,} | **MIPS (Loop Rate): {mips_core_display:.2f}**"
            
            screen.blit(small_font.render(rate_text,True,(255,200,150)),(50,y))
            screen.blit(small_font.render(total_text,True,(180,180,180)),(400,y))
            y+=row_height
        
    y += 10
    
    total_operations = total_blocks * loop_value
    
    screen.blit(font.render(f"Aggregate MIPS (Loop Rate): {total_mips:.2f}", True, (255,255,0)), (50,y))
    screen.blit(font.render(f"Total Operations: {int(total_operations):,}", True, (255,255,0)), (50,y+30))
    
    if tab['cores'] > visible_cores:
        scroll_indicator = f"Scroll: {scroll_offset+1}-{min(tab['cores'], scroll_offset + visible_cores)} of {tab['cores']} (W/S)"
        screen.blit(small_font.render(scroll_indicator, True, (255,150,0)), (700, HEIGHT - 50))
    
    if not is_running:
        screen.blit(small_font.render("Benchmark finished. Press ESC to return to menu.", True, (150,150,150)), (50, HEIGHT - 50))
    
    pygame.display.flip()

def draw_avx_tab(tab):
    global scroll_offset
    screen.fill((20,20,20))
    draw_logo(screen)
    draw_tabs()
    
    is_running = isinstance(benchmark_process, list) and any(p.is_alive() for p in benchmark_process)
    
    title_text = f"== {tab['name']} - {'RUNNING' if is_running else 'FINISHED'} =="
    title_color = (180, 0, 255) if is_running else (0,150,255) 
    screen.blit(font.render(title_text,True,title_color),(WIDTH//2 - len(title_text)*6,120))
    
    elapsed_time = time.time() - tab['start']
    remaining = max(0, tab['duration'] - elapsed_time)
    
    system_load = psutil.cpu_percent(interval=None) if is_running else 0.0
    screen.blit(small_font.render(f"CPU: {CPU_MODEL}", True, (0,150,255)), (20, 160))
    screen.blit(small_font.render(f"Overall Load: {system_load:.1f}%", True, (0,255,0)), (20, 180))
    
    time_text = f"Time: {elapsed_time:.1f}/{tab['duration']}s ({remaining:.1f}s left)"
    screen.blit(font.render(time_text, True, (255,255,0)), (WIDTH - 300, 160))
    
    y=210
    row_height = 25
    visible_cores = 12 

    max_scroll = max(0, tab['cores'] - visible_cores)
    scroll_offset = max(0, min(scroll_offset, max_scroll))

    total_flops = 0.0
    
    if results_list is not None: 
        for idx_agg in range(tab['cores']):
            base_index = idx_agg * 2
            try:
                total_flops_core = results_list[base_index] 
                total_flops += total_flops_core
            except IndexError:
                total_flops_core = 0.0

        aggregate_gflops = (total_flops / elapsed_time) / 1_000_000_000 if elapsed_time > 0 and elapsed_time < tab['duration'] else 0.0

        for i in range(visible_cores):
            idx = scroll_offset + i
            if idx >= tab['cores']:
                break
                
            base_index = idx * 2
            
            try:
                total_flops_core = results_list[base_index]
                current_gflops = results_list[base_index + 1]
                
            except IndexError:
                total_flops_core, current_gflops = 0.0, 0.0
            
            gflops_text = f"C{idx:02} | Current GFLOPS: {current_gflops:.2f}"
            total_text = f"| Total FLOPs: {int(total_flops_core):,}"
            
            screen.blit(small_font.render(gflops_text,True,(200,150,255)),(50,y))
            screen.blit(small_font.render(total_text,True,(180,180,180)),(400,y))
            y+=row_height
        
    y += 10
    
    screen.blit(font.render(f"Aggregate GFLOPS: {aggregate_gflops:.2f}", True, (255,255,0)), (50,y))
    screen.blit(font.render(f"Total FLOPs Executed: {int(total_flops):,}", True, (255,255,0)), (50,y+30))
    
    if tab['cores'] > visible_cores:
        scroll_indicator = f"Scroll: {scroll_offset+1}-{min(tab['cores'], scroll_offset + visible_cores)} of {tab['cores']} (W/S)"
        screen.blit(small_font.render(scroll_indicator, True, (255,150,0)), (700, HEIGHT - 50))
    
    if not is_running:
        screen.blit(small_font.render("Benchmark finished. Press ESC to return to menu.", True, (150,150,150)), (50, HEIGHT - 50))
    
    pygame.display.flip()


def draw_render_tab(tab):
    global scroll_offset
    screen.fill((20,20,20))
    draw_logo(screen)
    draw_tabs()
    
    is_running = isinstance(benchmark_process, list) and any(p.is_alive() for p in benchmark_process)
    
    title_text = f"== {tab['name']} - {'RUNNING' if is_running else 'FINISHED'} =="
    title_color = (0,255,100) if is_running else (0,150,255) 
    screen.blit(font.render(title_text,True,title_color),(WIDTH//2 - len(title_text)*6,120))
    
    elapsed_time = time.time() - tab['start']
    remaining = max(0, tab['duration'] - elapsed_time)
    
    screen.blit(small_font.render("Core 0 is running with a separate visual window for proof of work.", True, (255,100,100)), (WIDTH - 450, 200))

    time_text = f"Time: {elapsed_time:.1f}/{tab['duration']}s ({remaining:.1f}s left)"
    screen.blit(font.render(time_text, True, (255,255,0)), (WIDTH - 300, 160))
    
    y = 210 + 40 
    row_height = 40
    visible_cores = 8 

    cores = tab['cores']
    max_scroll = max(0, cores - visible_cores)
    scroll_offset = max(0, min(scroll_offset, max_scroll))

    total_fps = 0.0
    total_frames = 0.0
    finished_count = 0
    
    y = 250
    
    if results_list is not None: 
        for idx in range(cores):
            base_index = idx * 2
            try:
                fps = results_list[base_index]
                frames = results_list[base_index + 1]
            except IndexError:
                fps, frames = 0.0, 0.0
                
            total_fps += max(0, fps) 
            total_frames += frames
            if fps <= 0.0 and elapsed_time >= tab['duration'] and not (isinstance(benchmark_process, list) and benchmark_process[idx].is_alive()):
                finished_count += 1

        for i in range(visible_cores):
            idx = scroll_offset + i
            if idx >= cores:
                break
                
            base_index = idx * 2
            
            try:
                fps = results_list[base_index]
                frames = results_list[base_index + 1]
            except IndexError:
                fps, frames = 0.0, 0.0
            
            if fps < 0:
                status, color = "ERROR", (255, 0, 0)
            elif fps > 0:
                status, color = "RUNNING", (0, 255, 0)
            else:
                if elapsed_time >= tab['duration'] and isinstance(benchmark_process, list) and not benchmark_process[idx].is_alive():
                    status, color = "DONE", (150, 150, 150)
                else:
                    status, color = "PENDING/STOPPED", (255, 200, 0)
            
            if idx == 0 and is_running:
                status += " (VISUAL)"
                
            fps_text = f"Core {idx:02}: {fps:6.1f} FPS | Frames: {int(frames):,}"
            
            screen.blit(font.render(fps_text,True,color),(50,y))
            screen.blit(small_font.render(status,True,color),(450,y + 5))
            y+=row_height
        
    y += 10
    
    avg_fps = total_fps / max(1, cores) 
    
    screen.blit(font.render(f"Aggregate FPS: {avg_fps:.1f}", True, (0,255,255)), (50,y))
    screen.blit(font.render(f"Total Frames: {int(total_frames):,}", True, (0,255,255)), (50,y+30))
    
    if cores > visible_cores:
        scroll_indicator = f"Scroll: {scroll_offset+1}-{min(cores, scroll_offset + visible_cores)} of {cores} (W/S)"
        screen.blit(small_font.render(scroll_indicator, True, (255,150,0)), (700, HEIGHT - 50))
    
    if not is_running and finished_count == cores:
        screen.blit(small_font.render("BENCHMARK FINISHED. Press ESC to return to menu.", True, (150,150,150)), (50, HEIGHT - 50))
    
    pygame.display.flip()

def run_integer_loop_benchmark():
    global running_benchmark, results_list, benchmark_process
    
    if isinstance(benchmark_process, list):
        for p in benchmark_process:
            if p and p.is_alive():
                p.terminate()
                p.join(timeout=1)
                
    cores = os.cpu_count()
    
    mode_name = benchmark_modes["CubeIntLoop"][selected_diff].lower()
    profile = mode_name
    value = settings["intloop"][profile]["loop_value"]
    duration = settings["intloop"][profile]["time"]
    type_str = "INTLOOP"
    run_name = f"CubeIntLoop ({mode_name.upper()})"

    results_array = mp.Array('d', cores * 2) 
    results_list = results_array 
    
    new_processes = []
    for i in range(cores):
        p = mp.Process(target=benchmark_worker_int_loop, args=(i, value, duration, results_list))
        new_processes.append(p)
        p.start()
        
    benchmark_process = new_processes
    
    running_benchmark = {
        "name": run_name,
        "duration": duration,
        "start": time.time(),
        "cores": cores,
        "type": type_str,
        "loop_value": value
    }

def run_avx_benchmark():
    global running_benchmark, results_list, benchmark_process
    
    if isinstance(benchmark_process, list):
        for p in benchmark_process:
            if p and p.is_alive():
                p.terminate()
                p.join(timeout=1)
                
    cores = os.cpu_count()
    
    mode_name = benchmark_modes["CubeAVX"][selected_diff].lower()
    profile = mode_name
    value = settings["avx"][profile]["loop_value"]
    duration = settings["avx"][profile]["time"]
    type_str = "AVX"
    run_name = f"CubeAVX ({mode_name.upper()})"

    results_array = mp.Array('d', cores * 2) 
    results_list = results_array 
    
    new_processes = []
    for i in range(cores):
        p = mp.Process(target=benchmark_worker_avx, args=(i, value, duration, results_list))
        new_processes.append(p)
        p.start()
        
    benchmark_process = new_processes
    
    running_benchmark = {
        "name": run_name,
        "duration": duration,
        "start": time.time(),
        "cores": cores,
        "type": type_str,
        "loop_value": value
    }


def run_script():
    global active_tab, open_tabs, selected_diff, selected_bench, menu_state, settings_scroll_offset
    bench = benchmarks[selected_bench]

    if bench == "CubeIntLoop":
        if "CubeIntLoop" not in open_tabs: open_tabs.append("CubeIntLoop")
        active_tab="CubeIntLoop"
        menu_state = "MAIN_LIST"
        run_integer_loop_benchmark()
        
    elif bench == "CubeAVX":
        if "CubeAVX" not in open_tabs: open_tabs.append("CubeAVX")
        active_tab="CubeAVX"
        menu_state = "MAIN_LIST"
        run_avx_benchmark()
        
    elif bench == "CubeRender":
        
        mode_name = benchmark_modes[bench][selected_diff].lower()
        profile = mode_name
        lat = settings["render"][profile]["lat"]
        lon = settings["render"][profile]["lon"]
        time_val = settings["render"][profile]["time"]
        cores = os.cpu_count()

        if "CubeRender" not in open_tabs: open_tabs.append("CubeRender")
        active_tab = "CubeRender"
        menu_state = "MAIN_LIST"
        
        global running_benchmark, results_list, benchmark_process
        if isinstance(benchmark_process, list):
            for p in benchmark_process:
                if p and p.is_alive():
                    p.terminate()
                    p.join(timeout=1)
        
        results_array = mp.Array('d', cores * 2) 
        results_list = results_array 
        
        new_processes = []
        for i in range(cores):
            p = mp.Process(target=render_worker_unified, args=(lat, lon, time_val, i, results_list)) 
            new_processes.append(p)
            p.start()
            
        benchmark_process = new_processes
        
        running_benchmark = {
            "name": f"CubeRender ({mode_name.upper()})",
            "duration": time_val,
            "start": time.time(),
            "cores": cores,
            "type": "RENDER",
            "lat": lat,
            "lon": lon
        }
        
    elif bench == "CubeMonitor":
        if "CubeMonitor" not in open_tabs: open_tabs.append("CubeMonitor")
        active_tab = "CubeMonitor"
        menu_state = "MAIN_LIST"
        
    elif bench == "CubeMenu":
        active_tab = "CubeMenu"
        menu_state = "MAIN_LIST"
        
    elif bench == "Settings":
        active_tab = "CubeMenu"
        menu_state = "SETTINGS_EDIT" 
        selected_diff = 0
        settings_scroll_offset = 0


if __name__ == '__main__':
    
    if platform.system() == "Windows":
        mp.freeze_support() 
        mp.set_start_method("spawn", force=True)
    
    skip_admin_check = "--skip-admin-check" in sys.argv
    
    if not is_admin() and not skip_admin_check:
        relaunch_args = sys.argv + ['--skip-admin-check']
        
        try:
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(relaunch_args), None, 1)
            sys.exit()
        except Exception:
            pass
    
    try:
        pygame.init()
        screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Cube Benchmark System")
        font = pygame.font.SysFont("consolas",24)
        small_font = pygame.font.SysFont("consolas",18)
        clock = pygame.time.Clock()
        running = True
        
        psutil.cpu_percent(interval=None, percpu=True) 

        menu_items = [b for b in benchmarks if b not in ["CubeMonitor", "CubeMenu"]]
        if menu_items:
            selected_bench = benchmarks.index(menu_items[0])

        while running:
            
            is_any_bench_running = isinstance(benchmark_process, list) and any(p.is_alive() for p in benchmark_process)
            
            current_fps = 30 
            if is_any_bench_running:
                current_fps = 5 
            
            if active_tab == "CubeMonitor":
                draw_monitor_tab()
            elif active_tab == "CubeMenu":
                if menu_state == "MAIN_LIST":
                    draw_main_menu()
                elif menu_state == "DIFFICULTY_SELECT":
                    draw_diff_menu()
                elif menu_state == "SETTINGS_EDIT":
                    draw_settings_tab()
            elif active_tab == "CubeRender":
                if running_benchmark: draw_render_tab(running_benchmark)
            elif active_tab == "CubeIntLoop": 
                if running_benchmark: draw_intloop_tab(running_benchmark)
            elif active_tab == "CubeAVX":
                if running_benchmark: draw_avx_tab(running_benchmark)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = event.pos
                    
                    x_offset = 10
                    for tab_name in open_tabs:
                        if 10 <= my <= 50 and x_offset <= mx <= x_offset + 150:
                            active_tab = tab_name
                            break
                        x_offset += 160
                    
                elif event.type == pygame.KEYDOWN:
                    
                    if active_tab == "CubeMenu":
                        if menu_state == "MAIN_LIST":
                            menu_items = [b for b in benchmarks if b not in ["CubeMonitor", "CubeMenu"]]
                            
                            try:
                                current_index = menu_items.index(benchmarks[selected_bench])
                            except ValueError:
                                current_index = 0
                                if menu_items: selected_bench = benchmarks.index(menu_items[0])
                            
                            if event.key == pygame.K_w:
                                new_index = (current_index - 1) % len(menu_items)
                                selected_bench = benchmarks.index(menu_items[new_index])
                            elif event.key == pygame.K_s:
                                new_index = (current_index + 1) % len(menu_items)
                                selected_bench = benchmarks.index(menu_items[new_index])
                            elif event.key in [pygame.K_SPACE, pygame.K_RETURN]:
                                bench = benchmarks[selected_bench]
                                
                                if bench == "Settings":
                                    active_tab = "CubeMenu"
                                    menu_state = "SETTINGS_EDIT"
                                elif bench in ["CubeRender", "CubeIntLoop", "CubeAVX"]:
                                    menu_state = "DIFFICULTY_SELECT"
                                elif bench == "CubeMonitor":
                                    run_script()
                                
                            elif event.key == pygame.K_ESCAPE:
                                active_tab = "CubeMonitor"
                                
                        elif menu_state == "DIFFICULTY_SELECT":
                            bench = benchmarks[selected_bench]
                            if bench == "Settings":
                                menu_state = "SETTINGS_EDIT"
                                selected_diff = 0
                            else:
                                modes = benchmark_modes[benchmarks[selected_bench]]
                                if event.key == pygame.K_w:
                                    selected_diff = (selected_diff - 1) % len(modes)
                                elif event.key == pygame.K_s:
                                    selected_diff = (selected_diff + 1) % len(modes)
                                elif event.key in [pygame.K_SPACE, pygame.K_RETURN]:
                                    run_script()
                                    active_tab = bench
                                    menu_state = "MAIN_LIST"
                                elif event.key == pygame.K_ESCAPE:
                                    menu_state = "MAIN_LIST"
                                    selected_diff = 0
                            
                        elif menu_state == "SETTINGS_EDIT":
                            handle_settings_keyboard(event)

                    elif active_tab == "CubeMonitor":
                        if event.key == pygame.K_w:
                            scroll_offset = max(0, scroll_offset - 1)
                        elif event.key == pygame.K_s:
                            visible_cores = 10
                            max_scroll = max(0, os.cpu_count() - visible_cores)
                            scroll_offset = min(max_scroll, scroll_offset + 1)
                        elif event.key == pygame.K_ESCAPE:
                            active_tab = "CubeMenu"
                            
                    elif active_tab in ["CubeRender", "CubeIntLoop", "CubeAVX"]: 
                        
                        if event.key == pygame.K_ESCAPE:
                            is_running_after_check = isinstance(benchmark_process, list) and any(p.is_alive() for p in benchmark_process)
                            if not is_running_after_check:
                                active_tab = "CubeMenu"
                            
                        elif event.key == pygame.K_w:
                            scroll_offset = max(0, scroll_offset - 1)
                        elif event.key == pygame.K_s:
                            max_vis = 8 if active_tab == "CubeRender" else 12
                            max_scroll_tab = max(0, running_benchmark.get("cores", 0) - max_vis)
                            scroll_offset = min(max_scroll_tab, scroll_offset + 1)

            if is_any_bench_running and time.time() - running_benchmark['start'] >= running_benchmark['duration'] + 5:
                if isinstance(benchmark_process, list):
                    for p in benchmark_process:
                        if p and p.is_alive():
                            p.terminate()
                            p.join(timeout=1)
                
            clock.tick(current_fps)
        
    except Exception as e:
        with open("crash_log.txt","a") as f:
            f.write(f"\n--- Main Loop Error ---\n{time.ctime()}\n{traceback.format_exc()}\n")

    finally:
        if pygame.get_init():
            pygame.quit()
        
        if isinstance(benchmark_process, list):
            for p in benchmark_process:
                if p and p.is_alive():
                    p.terminate()
                    p.join(timeout=1)