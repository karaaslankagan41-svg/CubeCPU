import os, time, pygame, ctypes
import math
from multiprocessing import Process, cpu_count, set_start_method, Event, Array

TEST_DURATION = 60.0
CALIBRATE_SEC = 1.0
SAMPLE_INTERVAL = 0.18
WIDTH, HEIGHT = 420, 220
BAR_W, BAR_H_MAX = 72, 130


def intense_float_operation(x, j):
    x = x * 1.000000000001 + j * 0.000001
    x = x / (math.sqrt(abs(x)) + 0.001)
    x = x * 0.999999999999
    return x


def intense_float_operation_test(x, j):
    x = x * 1.000000000001 - j * 0.000001
    x = x / (math.pow(abs(x), 0.5) + 0.001)
    x = x * 0.999999999999
    return x

def worker(idx, start_ev, ready_flags, calib_rates, totals, offset_x, offset_y):
    os.environ['SDL_VIDEO_WINDOW_POS'] = f"{offset_x},{offset_y}"
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption(f"Core {idx}")
    font = pygame.font.SysFont("Consolas", 18)
    big = pygame.font.SysFont("Consolas", 28)


    end_cal = time.perf_counter() + CALIBRATE_SEC
    iters = 0
    x = 1.234567891234567
    while time.perf_counter() < end_cal:
        for i in range(600000):
            for j in range(5):
                x = intense_float_operation(x, i + j)
                iters += 1
    calib_rate = iters / CALIBRATE_SEC
    calib_rates[idx] = calib_rate
    ready_flags[idx] = 1

    start_ev.wait()
    start = time.perf_counter()
    endt = start + TEST_DURATION
    last_sample = time.perf_counter()
    window_iters = 0
    total = 0
    running = True

    
    while running:
        now = time.perf_counter()
        for i in range(600000):
            for j in range(5):
                x = intense_float_operation_test(x, i + j)
                window_iters += 1
                total += 1
                
        if now - last_sample >= SAMPLE_INTERVAL:
            iter_rate = window_iters / (now - last_sample)
            pct = min(100.0, (iter_rate / max(1.0, calib_rate)) * 100.0)
            rem = max(0.0, endt - now)
            screen.fill((12, 12, 12))
            bx = 32
            by = HEIGHT - 60 - int((pct / 100.0) * BAR_H_MAX)
            pygame.draw.rect(screen, (50, 50, 50), (bx, HEIGHT-60, BAR_W, BAR_H_MAX))
            pygame.draw.rect(screen, (0, 200, 0), (bx, by, BAR_W, int((pct / 100.0) * BAR_H_MAX)))
            screen.blit(big.render(f"{pct:5.1f}%", True, (200, 255, 200)), (130, 36))
            screen.blit(font.render(f"Iter/s: {iter_rate:,.0f}", True, (200, 200, 255)), (130, 76))
            screen.blit(font.render(f"Remaining: {rem:5.1f}s", True, (255, 220, 120)), (130, 108))
            screen.blit(font.render(f"Total: {total:,}", True, (180, 180, 180)), (130, 138))
            pygame.display.flip()
            window_iters = 0
            last_sample = now
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
        if now >= endt:
            running = False

    totals[idx] = total
    screen.fill((0, 0, 0))
    res = big.render(f"Done score: {total:,}", True, (120, 255, 120))
    screen.blit(res, (36, HEIGHT//2 - 12))
    pygame.display.flip()
    time.sleep(5)
    pygame.quit()

if __name__ == "__main__":
    try:
        set_start_method('spawn')
    except RuntimeError:
        pass

    pygame.init()
    menu_w, menu_h = 640, 320
    screen = pygame.display.set_mode((menu_w, menu_h))
    pygame.display.set_caption("CubeFloat")
    font = pygame.font.SysFont("Consolas", 24)

    while True:
        screen.fill((6,6,6))
        lines = [
            "CubeFloat 60s CPU Floating Point Stress (THERMAL LOAD)",
            "",
            "Press S for SINGLE-CORE test",
            "Press M for MULTI-CORE test",
            "Press Q to quit"
        ]
        for i, t in enumerate(lines):
            col = (0, 220, 0) if i>1 else (0,180,255)
            screen.blit(font.render(t, True, col), (36, 36 + i*48))
        pygame.display.flip()
        ev = pygame.event.wait()
        if ev.type == pygame.QUIT: pygame.quit(); os._exit(0)
        if ev.type == pygame.KEYDOWN:
            if ev.key == pygame.K_q: pygame.quit(); os._exit(0)
            if ev.key == pygame.K_s or ev.key == pygame.K_m:
                mode = "single" if ev.key == pygame.K_s else "multi"
                break

    cores = 1 if mode == "single" else cpu_count()
    start_ev = Event()
    ready = Array(ctypes.c_int, [0]*cores)
    calib_rates = Array(ctypes.c_double, [0.0]*cores)
    totals = Array(ctypes.c_ulonglong, [0]*cores)
    spacing_x = WIDTH + 24
    spacing_y = HEIGHT + 36
    procs = []
    for i in range(cores):
        ox = (i % 5) * spacing_x + 24
        oy = (i // 5) * spacing_y + 48
        p = Process(target=worker, args=(i, start_ev, ready, calib_rates, totals, ox, oy))
        p.start()
        procs.append(p)
    while True:
        if all(ready[i] == 1 for i in range(cores)): break
        time.sleep(0.03)
    time.sleep(0.1)
    start_ev.set()
    for p in procs: p.join()
    total_score = sum(int(totals[i]) for i in range(cores))
    pygame.init()
    res_screen = pygame.display.set_mode((640, 220))
    pygame.display.set_caption("CubeFloat - Results")
    big = pygame.font.SysFont("Consolas", 28)
    res_screen.fill((0,0,0))
    txt = big.render(f"All tests done. Final score: {total_score:,}", True, (80,255,120))
    res_screen.blit(txt, (28, 90))
    pygame.display.flip()
    time.sleep(6)
    pygame.quit()
    os._exit(0)