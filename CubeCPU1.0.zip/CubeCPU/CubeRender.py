import pygame
import math
import time
import os
import psutil
from multiprocessing import Process, Queue, cpu_count, set_start_method

def normalize(v):
    l = math.sqrt(sum(i*i for i in v))
    return tuple(i/l for i in v) if l else (0, 0, 0)

def dot(a, b): return sum(i*j for i, j in zip(a, b))

def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

def generate_uv_sphere(radius, lat, lon):
    verts, tris = [], []
    for i in range(lat + 1):
        theta = math.pi * i / lat
        sin_t, cos_t = math.sin(theta), math.cos(theta)
        for j in range(lon + 1):
            phi = 2 * math.pi * j / lon
            sin_p, cos_p = math.sin(phi), math.cos(phi)
            x = radius * sin_t * cos_p
            y = radius * cos_t
            z = radius * sin_t * sin_p
            verts.append((x, y, z))
    for i in range(lat):
        for j in range(lon):
            p1 = i * (lon + 1) + j
            p2 = p1 + lon + 1
            tris.append([verts[p1], verts[p2], verts[p1 + 1]])
            tris.append([verts[p1 + 1], verts[p2], verts[p2 + 1]])
    return tris

def project(x, y, z, width, height, fov):
    z += 300
    if z <= 1: return None
    f = fov / z
    sx = width // 2 + int(x * f)
    sy = height // 2 + int(y * f)
    return (sx, sy)

def draw_loop(worker_id, offset_x, offset_y, settings, queue, single):
    WIDTH, HEIGHT, FOV, SPHERE_RADIUS, LAT_SEGMENTS, LON_SEGMENTS, RENDER_DURATION, FPS_LIMIT, LIGHT_DIR = settings
    os.environ['SDL_VIDEO_WINDOW_POS'] = f"{offset_x},{offset_y}"
    if single:
        p = psutil.Process(os.getpid())
        p.cpu_affinity([0])
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption(f"Core {worker_id}")
    font = pygame.font.SysFont("Consolas", 16)
    clock = pygame.time.Clock()
    tris = generate_uv_sphere(SPHERE_RADIUS, LAT_SEGMENTS, LON_SEGMENTS)
    light = normalize(LIGHT_DIR)
    frame_count = 0
    start_time = time.time()
    while time.time() - start_time < RENDER_DURATION:
        screen.fill((0, 0, 0))
        frame_count += 1
        all_polygons = []
        for tri in tris:
            transformed = []
            for x, y, z in tri:
                y += math.sin(frame_count * 0.01 + x * 0.01 + z * 0.01) * 5
                transformed.append((x, y, z))
            a, b, c = transformed
            ab = [b[i]-a[i] for i in range(3)]
            ac = [c[i]-a[i] for i in range(3)]
            normal = normalize(cross(ab, ac))
            brightness = max(0.1, dot(normal, light))
            avg_z = sum(p[2] for p in transformed) / 3
            projected = [project(*p, WIDTH, HEIGHT, FOV) for p in transformed]
            if all(projected):
                all_polygons.append((projected, brightness, avg_z))
        all_polygons.sort(key=lambda x: -x[2])
        for poly, brightness, _ in all_polygons:
            c = int(255 * brightness)
            pygame.draw.polygon(screen, (c, c, c), poly)
        fps_text = font.render(f"Frames: {frame_count}", True, (0, 255, 0))
        screen.blit(fps_text, (10, 10))
        pygame.display.flip()
        if FPS_LIMIT > 0:
            clock.tick(FPS_LIMIT)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
    queue.put(frame_count)
    pygame.quit()

if __name__ == "__main__":
    try:
        set_start_method("spawn")
    except RuntimeError:
        pass

    print("=== Render Benchmark ===")
    core_mode = input("Single-core or Multi-core test? (S/M): ").strip().lower()
    print("[L] Low      (lat 20, lon 10)")
    print("[M] Medium   (lat 50, lon 10)")
    print("[H] High     (lat 50, lon 20)")
    print("[E] Extreme  (lat 100, lon 50)")
    print("[C] Custom")
    mode = input("Select mode: ").strip().lower()

    RENDER_DURATION = 60
    if mode == "l":
        LAT_SEGMENTS, LON_SEGMENTS, FPS_LIMIT = 20, 10, 0
    elif mode == "m":
        LAT_SEGMENTS, LON_SEGMENTS, FPS_LIMIT = 50, 10, 0
    elif mode == "h":
        LAT_SEGMENTS, LON_SEGMENTS, FPS_LIMIT = 50, 20, 0
    elif mode == "e":
        LAT_SEGMENTS, LON_SEGMENTS, FPS_LIMIT = 100, 50, 0
    else:
        LAT_SEGMENTS = int(input("Lat segments: "))
        LON_SEGMENTS = int(input("Lon segments: "))
        FPS_LIMIT = int(input("FPS limit (0 = unlimited): "))

    total_cores = cpu_count()
    single = core_mode == "s"
    num_workers = 1 if single else total_cores
    print(f"Using {num_workers} core(s)")
    time.sleep(1)

    WIDTH, HEIGHT = 300, 300
    FOV = 300
    SPHERE_RADIUS = 80
    LIGHT_DIR = (0, 1, -1)
    settings = (WIDTH, HEIGHT, FOV, SPHERE_RADIUS, LAT_SEGMENTS, LON_SEGMENTS, RENDER_DURATION, FPS_LIMIT, LIGHT_DIR)

    q = Queue()
    processes = []
    spacing = 20
    for i in range(num_workers):
        offset_x = (i % 4) * (WIDTH + spacing)
        offset_y = (i // 4) * (HEIGHT + spacing)
        p = Process(target=draw_loop, args=(i, offset_x, offset_y, settings, q, single))
        p.start()
        processes.append(p)

    pygame.init()
    screen = pygame.display.set_mode((600, 450))
    pygame.display.set_caption("CPU Load Monitor")
    font = pygame.font.SysFont("Consolas", 22)
    running = True
    finished = False
    total_frames = 0
    result_value = 0.0

    while running:
        screen.fill((10, 10, 10))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        if not finished:
            cpu_usages = psutil.cpu_percent(percpu=True)
            for i, usage in enumerate(cpu_usages):
                color = (255, 50, 50) if usage > 80 else (255, 255, 0) if usage > 50 else (0, 255, 0)
                pygame.draw.rect(screen, color, (50, 40 + i * 20, int(usage * 5), 15))
                text = font.render(f"Core {i}: {usage:.1f}%", True, (200, 200, 200))
                screen.blit(text, (300, 35 + i * 20))
            alive = any(p.is_alive() for p in processes)
            if not alive:
                while not q.empty():
                    total_frames += q.get()
                result_value = total_frames / 10.0
                finished = True
        else:
            done_text = font.render("Render complete.", True, (0, 255, 0))
            result_text = font.render(f"Result: {result_value:.2f}", True, (0, 255, 255))
            screen.blit(done_text, (180, 150))
            screen.blit(result_text, (230, 200))
        pygame.display.flip()
        time.sleep(0.2)

    pygame.quit()
    for p in processes:
        p.join()
