import subprocess

def run_script(script_name):
    subprocess.run(["python", script_name])

def main():
    print("=== Cube Benchmark Launcher ===")
    print("1. Run CubeAVX")
    print("2. Run CubeInt")
    print("3. Run CubeRender")
    choice = input("Select an option (1-3): ")

    if choice == "1":
        run_script("CubeAVX.py")
    elif choice == "2":
        run_script("CubeInt.py")
    elif choice == "3":
        run_script("CubeRender.py")
    else:
        print("Invalid choice.")

if __name__ == "__main__":
    main()